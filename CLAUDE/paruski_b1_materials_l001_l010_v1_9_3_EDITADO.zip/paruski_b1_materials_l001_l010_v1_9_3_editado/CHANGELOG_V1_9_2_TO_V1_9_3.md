# Changelog v1.9.2 → v1.9.3

- Incluidos y verificados los 117 archivos originales de L011–L100.
- Eliminada la referencia inexistente `correction_ne_a`.
- Revisados y alineados los targets de las 40 lecturas; corregida la contradicción temporal de L009.
- Revisados los 20 information gaps y corregidas sus dependencias y programación.
- Revisados los 50 exámenes y corregidos cuatro casos semánticos/curriculares.
- Reescritos los 182 diagnósticos de distractor con categorías y causas concretas.
- Sincronizados ejercicios, compat, perfiles y plan de evaluación.
