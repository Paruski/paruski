#!/usr/bin/env python3
"""Selective closing patch from Paruski v1.9.2 to v1.9.3."""
from __future__ import annotations

import csv
import hashlib
import json
import re
import shutil
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work_v19_2" / "paruski_b1_materials_l001_l010_v1_9_2"
SRC_ZIP = ROOT / "deliverables_v19_2" / "paruski_b1_materials_l001_l010_v1_9_2.zip"
ORIGINAL_V12 = ROOT / "upload" / "paruski_b1_materials_corrected_l001_l100_v1_2(2).zip"
ORIGINAL_TREE = ROOT / "work" / "paruski_b1_materials_corrected_l001_l100_v1_2"
OUT = ROOT / "work_v19_3" / "paruski_b1_materials_l001_l010_v1_9_3"
CONTENT = OUT / "content"


def load(name):
    return json.loads((SRC / "content" / name).read_text(encoding="utf-8"))


def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path, rows, fields=None):
    fields = fields or (list(rows[0]) if rows else ["status"])
    with path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


def lesson_num(value):
    m = re.search(r"(\d+)$", value or "")
    return int(m.group(1)) if m else None


def canonical(ex):
    return ex.get("referenceAnswer") or ex.get("expectedAnswer") or ex.get("structuredExpected", {}).get("referenceAnswer")


def sync_reference(ex, answer, variants=None):
    ex["referenceAnswer"] = answer
    ex["expectedAnswer"] = None if ex.get("openWithRubric") else answer
    if not ex.get("openWithRubric"):
        ex["acceptedAnswers"] = variants or [answer]
    se = ex.setdefault("structuredExpected", {})
    se["referenceAnswer"] = answer
    if "requiredAnswer" in se:
        se["requiredAnswer"] = answer
    for key in ("referenceResponse", "referenceExchange"):
        if key in se: se[key] = answer
    if "requiredCorrection" in se and isinstance(se["requiredCorrection"], str):
        se["requiredCorrection"] = answer
    for elt in se.get("requiredElements", []):
        if isinstance(elt, dict) and "evidenceInReference" in elt:
            elt["evidenceInReference"] = answer


# Each row was read against the Russian text, question and answer.  The mapping
# is deliberately explicit so target changes are reviewable rather than inferred
# from exercise type.
READING_ALIGNMENT = {
"pb1v16-l001-reading-comprehension-03-3":("locative_zero_copula",["zero_copula_identity"],"distinguir quién está aquí y quién está allí","Анна здесь. Иван там.","edit"),
"pb1v16-l001-reading-comprehension-06-2":("alphabet_cyrillic",[],"detectar el carácter latino dentro de una palabra rusa","кот frente a кoт","keep"),
"pb1v16-l001-reading-comprehension-09-1":("locative_zero_copula",["zero_copula_identity"],"localizar cuál de las bebidas está aquí","Кофе здесь. Чай там.","edit"),
"pb1v16-l001-reading-comprehension-11-5":("locative_zero_copula",["identity_answer_eto","personal_pronoun_reference"],"integrar identidad y ubicación del mismo referente","Это мама; Она тут","keep"),
"pb1v16-l002-reading-comprehension-03-3":("identity_answer_eto",[],"reconocer qué hombre recibe la categoría de tío","Это дядя.","edit"),
"pb1v16-l002-reading-comprehension-06-2":("kto_chto_animacy",["identity_answer_eto"],"inferir si la variable desconocida es animada o inanimada","Кто... человек; Что... книга","keep"),
"pb1v16-l002-reading-comprehension-09-1":("locative_zero_copula",["identity_answer_eto"],"identificar las dos personas que comparten la ubicación тут","Бабушка тут. Дедушка тут.","edit"),
"pb1v16-l002-reading-comprehension-11-5":("identity_answer_eto",["kto_chto_animacy"],"extraer la identidad nominal de la mujer","Это Анна.","keep"),
"pb1v16-l003-reading-comprehension-03-3":("locative_zero_copula",["connector_i_addition"],"relacionar la hija con la ubicación de los alimentos","Дочь тут; Хлеб, рыба и мясо тут","edit"),
"pb1v16-l003-reading-comprehension-06-2":("locative_zero_copula",["connector_a_reference_contrast"],"contrastar la ubicación de silla y mesa","Стул тут, а стол там.","edit"),
"pb1v16-l003-reading-comprehension-09-1":("connector_i_addition",["identity_negation_ne"],"recuperar los dos elementos coordinados que el cliente confirma","чай и хлеб; Кофе — нет","edit"),
"pb1v16-l003-reading-comprehension-11-5":("locative_zero_copula",["connector_a_reference_contrast"],"decidir qué familiar ocupa la posición там","Мама здесь, папа там.","edit"),
"pb1v16-l004-reading-comprehension-03-3":("possession_u_genitive_est",["connector_a_reference_contrast"],"asignar cada posesión a su poseedor","У Анны есть фильм, а у Ивана есть музыка.","edit"),
"pb1v16-l004-reading-comprehension-06-2":("absence_net_genitive",["genitive_possessor_pronouns","possession_u_genitive_est"],"contrastar documento presente y documento ausente","есть паспорт; билета нет","edit"),
"pb1v16-l004-reading-comprehension-09-1":("possession_u_genitive_est",[],"asignar pregunta y respuesta a sus poseedores","У Анны есть вопрос. У Ивана есть ответ.","edit"),
"pb1v16-l004-reading-comprehension-11-5":("possession_vs_identification",["connector_a_reference_contrast"],"distinguir el objeto identificado del objeto atribuido a Ana","Ключ у Анны.","keep"),
"pb1v16-l005-reading-comprehension-03-3":("adjective_gender_number_agreement",[],"vincular valoraciones adjetivales con libro y ejemplo","Книга хорошая; плохой пример","edit"),
"pb1v16-l005-reading-comprehension-06-2":("absence_net_genitive",["possession_u_genitive_est"],"inferir quién carece de trabajo pero dispone de tiempo","У Ивана нет работы, но есть время.","keep"),
"pb1v16-l005-reading-comprehension-09-1":("adjective_gender_number_agreement",["possessive_gender_number_agreement"],"identificar el objeto descrito como nuevo","моя новая тетрадь","keep"),
"pb1v16-l005-reading-comprehension-11-5":("possessive_gender_number_agreement",["gender_inference","adjective_gender_number_agreement"],"reconocer la carta propia mediante моё","Это моё письмо.","edit"),
"pb1v16-l006-reading-comprehension-03-3":("formal_informal_register",["personal_pronoun_reference"],"identificar el saludo formal dirigido a la profesora","Здравствуйте","edit"),
"pb1v16-l006-reading-comprehension-06-2":("eto_vs_personal_pronoun",["personal_pronoun_reference"],"explicar el paso de identificación inicial a referencia pronominal","Это Анна. Она здесь. Это Иван. Он там.","edit"),
"pb1v16-l006-reading-comprehension-09-1":("formal_informal_register",[],"distinguir saludo formal de saludo entre amigos","Здравствуйте frente a Привет","edit"),
"pb1v16-l006-reading-comprehension-11-5":("formal_informal_register",[],"seleccionar el saludo usado por un amigo","Друг: Привет!","edit"),
"pb1v16-l007-reading-comprehension-03-3":("present_conjugation_zhit",["personal_pronoun_reference"],"comparar dónde viven o estudian Ana e Iván","Он живёт в Испании; Она учится в Москве","edit"),
"pb1v16-l007-reading-comprehension-06-2":("present_conjugation_zhit",["subject_verb_agreement"],"integrar la residencia común del plural они","Они живут в России.","keep"),
"pb1v16-l007-reading-comprehension-09-1":("present_conjugation_delat_znat",["answer_question_compatibility"],"contrastar conocimiento y actividad","знаешь/знаю; делаешь/нет","keep"),
"pb1v16-l007-reading-comprehension-11-5":("subject_verb_agreement",["present_conjugation_zhit"],"vincular сестра con la forma singular живёт","сестра живёт в Испании","keep"),
"pb1v16-l008-reading-comprehension-03-3":("read_write_speak_contrast",["present_conjugation_govorit_chitat_pisat"],"asignar escribir, leer y detectar a participantes distintos","Анна пишет; Иван читает; Иван говорит","edit"),
"pb1v16-l008-reading-comprehension-06-2":("present_conjugation_govorit_chitat_pisat",["read_write_speak_contrast"],"ordenar las actividades anteriores a la lectura","понимают и пишут; Потом читают","keep"),
"pb1v16-l008-reading-comprehension-09-1":("read_write_speak_contrast",[],"identificar quién realiza la acción de leer el texto","Анна читает текст.","keep"),
"pb1v16-l008-reading-comprehension-11-5":("language_adverb_po",["read_write_speak_contrast"],"extraer el idioma asociado a читаю","читаю по-русски","edit"),
"pb1v16-l009-reading-comprehension-03-3":("present_conjugation_govorit_chitat_pisat",["wh_semantic_scope"],"asignar acciones a dos momentos distintos","Утром пишет; Днём работает","edit"),
"pb1v16-l009-reading-comprehension-06-2":("answer_question_compatibility",["wh_semantic_scope","absence_net_genitive"],"relacionar la pregunta causal con la falta de tiempo","Почему? — Утром нет времени.","keep"),
"pb1v16-l009-reading-comprehension-09-1":("wh_semantic_scope",["locative_zero_copula"],"distinguir una variable de lugar de una variable temporal","Где frente a Когда","edit"),
"pb1v16-l009-reading-comprehension-11-5":("answer_question_compatibility",["yes_no_question"],"interpretar dos respuestas negativas a preguntas totales distintas","Это правильно? — Нет; Это плохо? — Нет","edit"),
"pb1v16-l010-reading-comprehension-03-3":("integrated_question_scope",["answer_question_compatibility"],"inferir quién no está preparado a partir de dos estados contrastados","Анна уже готова, Иван ещё не готов.","edit"),
"pb1v16-l010-reading-comprehension-06-2":("integrated_identity_reference",["personal_pronoun_reference","locative_zero_copula"],"mantener cada persona al pasar de identificación a pronombre y ubicación","Это Анна. Она здесь; Это Иван. Он там.","edit"),
"pb1v16-l010-reading-comprehension-09-1":("integrated_present_actions",["read_write_speak_contrast"],"asignar escritura, lectura y evaluación a tres participantes","Анна пишет; Иван читает; преподаватель говорит","edit"),
"pb1v16-l010-reading-comprehension-11-5":("integrated_question_scope",["answer_question_compatibility"],"reconocer la aceptación y después resolver una pregunta de identidad","Вы готовы? — Конечно; кто это? — Это мой брат","keep"),
}

READING_TEXT_PATCHES = {
"pb1v16-l006-reading-comprehension-06-2":("Dos personas aparecen por primera vez y luego se retoman. Lee el texto y explica en español por qué se usa это primero y она/он después.","Это Анна. Она здесь. Это Иван. Он там.","Это identifica a cada persona al presentarla; она y он la retoman después."),
"pb1v16-l006-reading-comprehension-09-1":("Lee los dos saludos y responde en español: ¿cuál se dirige a la profesora y cuál a un amigo?","Преподаватель: «Здравствуйте!» Потом друг: «Привет!»","Здравствуйте se dirige a la profesora; Привет, al amigo."),
"pb1v16-l009-reading-comprehension-03-3":("Lee el horario de Ana y responde en español: ¿qué hace por la mañana y durante el día?","Утром Анна пишет. Днём она работает. Вечером она читает.","Por la mañana escribe y durante el día trabaja."),
"pb1v16-l010-reading-comprehension-06-2":("Lee el diálogo y responde en español: ¿quién está aquí y quién está allí?","— Кто это? — Это Анна. Она здесь. — А кто это? — Это Иван. Он там.","Ana está aquí e Iván está allí."),
"pb1v16-l010-reading-comprehension-09-1":("Lee el texto y responde en español: ¿quién escribe, quién lee y quién evalúa la respuesta?","Анна пишет ответ. Иван читает ответ. Преподаватель говорит: «Ответ правильный».","Ana escribe, Iván lee y la profesora evalúa la respuesta como correcta."),
}

GAP_PATCHES = {
"pb1v16-l001-information-gap-reconstruction-05-5":("zero_copula_identity",["locative_zero_copula","kto_chto_animacy"],None,None),
"pb1v16-l001-information-gap-reconstruction-06-5":("locative_zero_copula",["question_answer_alignment","kto_chto_animacy"],None,None),
"pb1v16-l003-information-gap-reconstruction-05-5":("identity_negation_ne",["zero_copula_identity"],None,None),
"pb1v16-l003-information-gap-reconstruction-06-5":("connector_a_reference_contrast",["kto_chto_animacy","identity_answer_eto"],"Tarjeta A: Sabes que la mujer es la madre, pero no sabes quién es el hombre.\nTarjeta B: Sabes que el hombre es el padre, pero no sabes quién es la mujer.","— Кто это? — Это папа. — А кто это? — Это мама."),
"pb1v16-l004-information-gap-reconstruction-05-5":("absence_net_genitive",["possession_u_genitive_est","genitive_possessor_pronouns"],"Tarjeta A: Sabes que Ana tiene pasaporte, pero no sabes si tiene billete.\nTarjeta B: Sabes que Ana no tiene billete, pero no sabes si tiene pasaporte.","— У Анны есть билет? — Нет, у неё нет билета. — У неё есть паспорт? — Да, есть."),
"pb1v16-l004-information-gap-reconstruction-06-5":("possession_u_genitive_est",["absence_net_genitive","genitive_possessor_pronouns"],"Tarjeta A: Sabes que Ana tiene llave, pero no sabes si Iván tiene una.\nTarjeta B: Sabes que Iván no tiene llave, pero no sabes si Ana tiene una.","— У Ивана есть ключ? — Нет, у него нет ключа. — У Анны есть ключ? — Да, у неё есть ключ."),
"pb1v16-l005-information-gap-reconstruction-05-5":("possessive_gender_number_agreement",["identity_answer_eto"],"Tarjeta A: Ves a una mujer, pero no sabes quién es.\nTarjeta B: Sabes que es la hermana del hablante.","— Кто это? — Это моя сестра."),
"pb1v16-l005-information-gap-reconstruction-06-5":("adjective_gender_number_agreement",["identity_answer_eto"],"Tarjeta A: Sabes que el objeto es nuevo, pero no sabes qué es.\nTarjeta B: Sabes que es una carta, pero no sabes si es nueva.","— Что это? — Это письмо. — Письмо новое? — Да."),
"pb1v16-l007-information-gap-reconstruction-06-5":("present_conjugation_delat_znat",["subject_verb_agreement"],None,None),
"pb1v16-l008-information-gap-reconstruction-06-5":("read_write_speak_contrast",["present_conjugation_govorit_chitat_pisat"],"Tarjeta A: Sabes que Ana escribe el mensaje, pero no sabes quién lo lee.\nTarjeta B: Sabes que Iván lee el mensaje, pero no sabes quién lo escribe.","— Кто пишет сообщение? — Анна. — Кто читает сообщение? — Иван."),
}

EXAM_PATCHES = {
"pb1v16-l002-exam-13-4":("alphabet_cyrillic",[],"Evaluación. Lee el nombre «Иван» de una tarjeta y presenta a esa persona.","Это Иван."),
"pb1v16-l003-exam-13-2":("connector_i_addition",["kto_chto_animacy","locative_zero_copula"],"Evaluación de transferencia. En una mesa, pregunta qué son los elementos señalados, identifícalos como pan y queso e indica que el queso está aquí.","— Что это? — Это хлеб и сыр. Сыр тут."),
"pb1v16-l003-exam-13-4":("identity_negation_ne",["connector_a_reference_contrast","locative_zero_copula"],"Evaluación de transferencia. Pregunta por el impreso, corrige a quien cree que es un periódico e indica que el periódico está allí.","— Что это? — Это не газета, а книга. Газета там."),
"pb1v16-l009-exam-13-2":("wh_semantic_scope",["present_conjugation_govorit_chitat_pisat"],"Evaluación de transferencia. Pregunta cuándo lee Ana y responde que lee al anochecer.","— Когда Анна читает? — Вечером."),
"pb1v16-l010-exam-13-1":("integrated_identity_reference",["integrated_question_scope","language_adverb_po"],None,None),
}

# Closed items whose stored canonical option still contradicted the situation in
# v1.9.2.  These are content fixes, not metadata-only changes.
CHOICE_FIXES = {
"pb1v16-l003-contrast-explanation-09-2": {
    "answer":"Это не вода.",
    "rationale":"El hablante sólo sabe que la bebida no es agua. La respuesta debe negar esa atribución sin inventar que sea zumo; por eso identity_negation_ne es la habilidad principal.",
    "success":"Это не вода rechaza la identificación conocida como falsa y no añade una alternativa que la escena no proporciona.",
    "error":"Это не вода, а сок sería posible sólo si el hablante supiera que la bebida es zumo; aquí inventa información.",
},
"pb1v16-l006-contrast-explanation-06-3": {
    "answer":"Это тетрадь. Она новая.",
    "rationale":"La guía presenta una libreta y después la retoma sin repetir el sustantivo. Это introduce el referente y она concuerda con el femenino тетрадь; la opción sobre Iván cambia persona, objeto y ubicación.",
    "success":"Это тетрадь presenta la libreta; Она новая la retoma con el pronombre femenino y añade la propiedad solicitada.",
    "error":"Это Иван. Он там habla de un hombre y de su ubicación; no presenta ni describe la libreta de la escena.",
},
"pb1v16-l006-semantic-contrast-10-5": {
    "answer":"До свидания!",
    "rationale":"La interacción con una profesora termina en registro formal. До свидания es una despedida formal; Привет es un saludo informal y además abre, no cierra, la conversación.",
    "success":"До свидания es la despedida adecuada para cerrar formalmente la conversación con la profesora.",
    "error":"Привет es un saludo informal de apertura; no funciona como despedida formal en esta situación.",
},
"pb1v16-l007-semantic-contrast-08-1": {
    "answer":"Я делаю задание.",
    "rationale":"La pregunta Что ты делаешь? solicita la actividad actual del interlocutor. La respuesta debe cambiar al sujeto я y producir делаю; repetir la pregunta no cierra el turno.",
    "success":"Я делаю задание responde con una actividad actual y usa делаю con el sujeto я.",
    "error":"Что ты делаешь? repite la pregunta de la profesora y no aporta la actividad del alumno.",
},
"pb1v16-l007-semantic-contrast-10-5": {
    "answer":"— Ты знаешь ответ? — Да, я знаю.",
    "rationale":"El segundo turno debe confirmar el conocimiento desde la perspectiva del alumno. Al cambiar de interlocutor, ты знаешь pasa a я знаю; repetir sólo la pregunta no constituye una respuesta.",
    "success":"El diálogo conserva la pregunta y ajusta persona y verbo en la respuesta: Да, я знаю.",
    "error":"Ты знаешь ответ? es únicamente la pregunta inicial; falta la confirmación del alumno con я знаю.",
},
}


def diagnostic_for(option, correct, prompt, old):
    lo, lc, lp = option.lower(), correct.lower(), prompt.lower()
    meaning = old.get("meaning") or f"La opción expresa «{option}»."
    category = old.get("category") or "reference_or_participant_change"
    why = old.get("whyItFails") or ""
    repair = correct
    if any(ch in lo for ch in "abcdefghijklmnopqrstuvwxyz") and any("CYRILLIC" in unicodedata.name(ch, "") for ch in option):
        category="mixed_script"; meaning="La palabra mezcla caracteres latinos y cirílicos visualmente parecidos."; why="La escritura rusa exigida debe mantener un único alfabeto; el carácter latino no es una variante cirílica."
    elif lo.startswith("вот"):
        category="presentation_instead_of_identification"; meaning="Presenta o señala el referente con «вот»."; why="La escena pide una identificación neutra con «это», no llamar la atención sobre la aparición o posición del referente."
    elif ("кто" in lo and "что" in lc):
        category="wrong_animacy_question"; meaning="«Кто» pregunta por una persona o un animal individualizado."; why="El referente de la escena es una cosa; la variable correcta se abre con «что»."
    elif ("что" in lo and "кто" in lc):
        category="wrong_animacy_question"; meaning="«Что» pregunta por una cosa o una categoría inanimada."; why="El referente es una persona o animal individualizado; la pregunta debe usar «кто»."
    elif lo.rstrip(".") + "?" == lc or (lo.endswith(".") and lc.endswith("?") and lo[:-1] == lc[:-1]):
        category="missing_question_mark"; meaning="Con punto, la secuencia se presenta gráficamente como enunciado."; why="La tarea exige formular una pregunta y el signo interrogativo forma parte de la modalidad escrita."
    elif " есть " in f" {lo} " and " есть " not in f" {lc} ":
        category="explicit_copula_in_identity"; meaning="Introduce «есть» como si fuera la cópula española en una identificación."; why="En la identificación nominal neutra en presente, «это» enlaza el referente y el nombre sin «есть»."
    elif any(x in lo for x in (" тут", " там", " здесь")) and any(x in lp for x in ("identific", "presenta", "qué es", "quién es")):
        category="location_instead_of_identification"; meaning="Informa de dónde está el referente."; why="La consigna pregunta qué o quién es; una localización deja sin resolver la identidad."
    elif lo.startswith("это") and any(x in lp for x in ("dónde", "ubic", "aquí", "allí")) and any(x in lc for x in ("тут", "там", "здесь")):
        category="identity_instead_of_location"; meaning="Identifica el referente mediante «это»."; why="La situación ya conoce la identidad y solicita una ubicación."
    elif " а " in f" {lo} " and " и " in f" {lc} ":
        category="wrong_connector_contrast"; meaning="«А» contrapone referentes o predicados."; why="La consigna suma elementos del mismo conjunto; debe usarse «и»."
    elif " но " in f" {lo} " and " и " in f" {lc} ":
        category="wrong_connector_contrast"; meaning="«Но» introduce una restricción o contraste adversativo."; why="La tarea añade dos elementos sin oposición; corresponde «и»."
    elif " и " in f" {lo} " and (" а " in f" {lc} " or " но " in f" {lc} "):
        category="wrong_connector_addition"; meaning="«И» añade información compatible."; why="La relación solicitada contrapone o corrige una alternativa, no acumula dos elementos."
    elif " но " in f" {lo} " and " а " in f" {lc} ":
        category="wrong_connector_correction"; meaning="«Но» expresa una restricción adversativa."; why="La estructura corrige una atribución y la sustituye por otra; la construcción elegida requiere «не X, а Y»."
    elif re.search(r"\b(?:мой|моя|моё|мои)\b", lo) and re.search(r"\b(?:мой|моя|моё|мои)\b", lc):
        category="possessive_agreement"; meaning="El posesivo no concuerda con el género o número del sustantivo ruso."; why="La forma posesiva se selecciona por el sustantivo ruso, no por la traducción española."
    elif re.search(r"\b[а-яё]+ть\b", lo) and not re.search(r"\b[а-яё]+ть\b", lc):
        category="infinitive_instead_of_finite_verb"; meaning="Usa un infinitivo donde la oración necesita un verbo personal."; why="El sujeto exige una forma conjugada que marque persona y número."
    elif any(x in lo for x in ("у ты", "у я")):
        category="wrong_possessor_case"; meaning="Mantiene el pronombre en nominativo después de «у»."; why="La construcción posesiva exige la forma oblicua: «у тебя» o «у меня»."
    elif " не " in f" {lo} " and " нет " in f" {lc} ":
        category="absence_marker"; meaning="Usa «не» como negación de una forma ausente."; why="La disponibilidad o existencia negativa se expresa con «нет» y la forma dependiente correspondiente."
    elif lo != lc:
        category="valid_answer_to_another_question" if old.get("category")=="valid_other_function" else "reference_or_participant_change"
        meaning=f"La opción produce «{option}», una relación distinta de «{correct}»."
        why=f"La consigna exige {prompt.split('Elige')[0].strip().rstrip('.')}; esta opción cambia la relación, el referente o la forma necesaria."
    return {"category":category,"meaning":meaning,"whyItFails":why,"repair":repair}


def copy_and_verify_untouched(manifest):
    dest = OUT / "untouched_l011_l100"
    for row in manifest["files"]:
        rel = Path(row["path"])
        src = ORIGINAL_TREE / Path(*rel.parts[1:])
        target = OUT / rel
        if not src.exists(): raise FileNotFoundError(src)
        if src.stat().st_size != row["size"] or hashlib.sha256(src.read_bytes()).hexdigest() != row["sha256"]:
            raise RuntimeError(f"L011-L100 source mismatch: {src}")
        target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src,target)
    actual = [p for p in dest.rglob("*") if p.is_file()]
    if len(actual) != 117: raise RuntimeError(f"Expected 117 untouched files, found {len(actual)}")


def main():
    if OUT.exists(): shutil.rmtree(OUT)
    CONTENT.mkdir(parents=True)
    (OUT/"source_v1_9_2").mkdir()
    shutil.copy2(SRC_ZIP, OUT/"source_v1_9_2"/SRC_ZIP.name)
    source_hash=hashlib.sha256(SRC_ZIP.read_bytes()).hexdigest()
    (OUT/"SOURCE_V1_9_2_SHA256.txt").write_text(f"{source_hash}  {SRC_ZIP.name}\n",encoding="utf-8")
    manifest=json.loads((SRC/"UNCHANGED_L011_L100_MANIFEST.json").read_text(encoding="utf-8"))
    if hashlib.sha256(ORIGINAL_V12.read_bytes()).hexdigest()!=manifest["sourceArchiveSha256"]: raise RuntimeError("Original v1.2 archive hash mismatch")
    copy_and_verify_untouched(manifest)
    dump(OUT/"UNCHANGED_L011_L100_MANIFEST.json",manifest)

    exercises=load("exercises_l001_l010_v1_9_2.json")
    profiles=load("exercise_adaptive_profiles_l001_l010_v1_9_2.json")
    skills=load("skills_l001_l010_v1_9_2.json")
    kernels=load("semantic_kernels_l001_l010_v1_9_2.json")
    trajectories=load("skill_trajectories_l001_l010_v1_9_2.json")
    assessments=load("assessment_plan_l001_l010_v1_9_2.json")
    vocab=load("vocabulary_l001_l010_v1_9_2.json")
    coverage=load("lexical_coverage_l001_l010_v1_9_2.json")
    encounters=load("lexical_encounters_l001_l010_v1_9_2.json")
    feedback=load("feedback_templates_v1_9_2.json")
    confusions=load("confusion_sets_v1_9_2.json")
    recovery=load("recovery_protocols_v1_9_2.json")
    normalization=load("normalization_policies_v1_9_2.json")
    progress=load("progress_model_schema_v1_9_2.json")
    eby={e["id"]:e for e in exercises}; pby={p["exerciseId"]:p for p in profiles}
    skill_intro={s["skillId"]:lesson_num(s["introducedInLesson"]) for s in skills}

    reading_rows=[]
    for eid,(primary,secondary,decision,evidence,edit) in READING_ALIGNMENT.items():
        ex=eby[eid]; old=ex["primarySkillId"]
        if eid in READING_TEXT_PATCHES:
            prompt,text,answer=READING_TEXT_PATCHES[eid]; ex["prompt"]=prompt;ex["input"]=text;sync_reference(ex,answer)
        ex["primarySkillId"]=primary;ex["secondarySkillIds"]=secondary
        ex["targetAlignmentRationale"]=(f"La pregunta exige {decision}. La evidencia es «{evidence}». "
            f"Por ello {primary} es principal; las habilidades secundarias sólo permiten interpretar elementos auxiliares.")
        ex["contentDecision"]="edit" if edit=="edit" else ex.get("contentDecision","keep")
        reading_rows.append({"exerciseId":eid,"currentPrimarySkillId":old,"requiredDecision":decision,"textualEvidence":evidence,
            "newPrimarySkillId":primary,"secondarySkillIds":"|".join(secondary),"decision":edit,"rationale":ex["targetAlignmentRationale"]})

    for eid,(primary,secondary,new_input,new_answer) in GAP_PATCHES.items():
        ex=eby[eid];ex["primarySkillId"]=primary;ex["secondarySkillIds"]=secondary
        if new_input: ex["input"]=new_input
        if new_answer:
            sync_reference(ex,new_answer);ex["validResponseExamples"]=[new_answer]
            ex["partiallyCorrectResponse"]="El intercambio resuelve sólo una de las lagunas; falta la pregunta o respuesta que necesita el otro participante."
            ex["incorrectPlausibleResponse"]="Una afirmación aislada no permite recuperar la información distribuida entre las tarjetas."
        ex["targetAlignmentRationale"]=(f"La laguna se resuelve principalmente mediante {primary}; "
            f"el intercambio visible exige esa forma y usa {', '.join(secondary) if secondary else 'ninguna skill secundaria'} como apoyo.")

    # Every information gap is practice/integration, never initial discovery.
    gap_rows=[]
    for ex in exercises:
        if ex["type"]!="information_gap_reconstruction": continue
        p=pby[ex["id"]]; primary=ex["primarySkillId"]; secondary=ex.get("secondarySkillIds",[])
        required=list(dict.fromkeys([primary]+secondary))
        ceiling=max([skill_intro.get(s,ex["lessonNumber"]) for s in required]+[ex["lessonNumber"]])
        if ex["id"]=="pb1v16-l008-information-gap-reconstruction-05-5":
            required=list(dict.fromkeys(required+["language_question_frame"]));ceiling=9
        p["primarySkillId"]=primary;p["secondarySkillIds"]=secondary;p["eligibleAfterSkillIds"]=required
        p["firstEligibleDelay"]="P7D" if ceiling>ex["lessonNumber"] else "P3D"
        p["firstEligibleLessonId"]=f"L{ceiling:03d}" if ceiling>ex["lessonNumber"] else None
        p["sessionFunction"]="weekly_review" if ceiling>ex["lessonNumber"] else "short_delay_review"
        p["assessmentRole"]="transfer_practice" if ceiling>ex["lessonNumber"] else "delayed_practice"
        p["masteryStateMeasured"]="contextual_transfer";p["responseGenerationMode"]="information_exchange";p["requiresFreeRecall"]=False
        se=ex.get("structuredExpected",{})
        gap_rows.append({"exerciseId":ex["id"],"primarySkillId":primary,"secondarySkillIds":"|".join(secondary),
          "introducedInLesson":skill_intro[primary],"requiredStructures":canonical(ex),"requiredVocabulary":" | ".join(re.findall(r"[А-Яа-яЁё-]+",canonical(ex) or "")),
          "firstEligibleDelay":p["firstEligibleDelay"],"sessionFunction":p["sessionFunction"],"eligibleAfterSkillIds":"|".join(required),
          "sourceLessonId":p["sourceLessonId"],"firstEligibleLessonId":p["firstEligibleLessonId"],"decision":"edit" if ex["id"] in GAP_PATCHES or ceiling>ex["lessonNumber"] else "keep",
          "rationale":"La tarea se programa después de todas las skills necesarias y no se usa como descubrimiento inicial."})

    for eid,(primary,secondary,prompt,answer) in EXAM_PATCHES.items():
        ex=eby[eid];ex["primarySkillId"]=primary;ex["secondarySkillIds"]=secondary
        if prompt: ex["prompt"]=prompt
        if answer: sync_reference(ex,answer)
        ex["targetAlignmentRationale"]=(f"La evaluación exige producir «{canonical(ex)}». La decisión principal corresponde a {primary}; "
            "las skills secundarias integran información explícitamente solicitada.")

    for eid,fix in CHOICE_FIXES.items():
        ex=eby[eid];answer=fix["answer"]
        sync_reference(ex,answer)
        se=ex.setdefault("structuredExpected",{})
        se["requiredAnswer"]=answer
        other=next((o for o in ex.get("options",[]) if o!=answer),None)
        if other is not None: se["forbiddenAlternative"]=other
        se["referenceIsExclusive"]=True
        ex["targetAlignmentRationale"]=fix["rationale"]
        ex["exerciseSpecificSuccessFeedback"]=fix["success"]
        ex["exerciseSpecificErrorFeedback"]=fix["error"]
        ex["contentDecision"]="edit"

    # Two replacement exercises retained an unrelated defective sentence in an
    # auxiliary input field.  The visible choice already contains all evidence.
    ex=eby["pb1v17-replacement-023"]
    ex["input"]=None
    ex["targetAlignmentRationale"]=("La situación pregunta por la posesión de una libreta. У тебя exige la forma oblicua тебя después de у; "
        "la alternativa sobre una hermana pertenece a otra situación y no responde a la pregunta de posesión.")
    ex=eby["pb1v17-replacement-028"]
    ex["input"]=None;ex["primarySkillId"]="eto_vs_personal_pronoun";ex["secondarySkillIds"]=["possessive_gender_number_agreement","locative_zero_copula"]
    ex["targetAlignmentRationale"]=("La tarea presenta al hermano con Это мой брат y lo retoma mediante Он. La concordancia de мой y la ubicación son necesarias, "
        "pero la decisión central es pasar de identificación a referencia pronominal sin cambiar de participante.")

    # Replace vague diagnostics with content-based structured diagnoses.
    diag_rows=[]
    for ex in exercises:
        correct=(ex.get("acceptedAnswers") or [canonical(ex) or ""])[0]
        old_diagnostics=ex.get("distractorDiagnostics",{})
        if ex.get("options"):
            candidates={option:old_diagnostics.get(option,{}) for option in ex["options"] if option.strip().lower()!=correct.strip().lower()}
            ex["distractorDiagnostics"]={}
        else:
            candidates=dict(old_diagnostics)
        for option,old in candidates.items():
            new=diagnostic_for(option,correct,ex["prompt"],old)
            ex["distractorDiagnostics"][option]=new
            generic="no satisface la función o la forma" in new["whyItFails"].lower()
            diag_rows.append({"exerciseId":ex["id"],"distractor":option,"category":new["category"],"meaning":new["meaning"],
              "whyItFails":new["whyItFails"],"repair":new["repair"],"genericOnly":generic,"decision":"pass" if not generic else "fail"})

    # Synchronize profiles and assessment plan after target/response edits.
    for ex in exercises:
        p=pby[ex["id"]];p["primarySkillId"]=ex["primarySkillId"];p["secondarySkillIds"]=ex.get("secondarySkillIds",[])
        if p.get("sessionFunction")=="initial_discovery":
            primary_skill=next(s for s in skills if s["skillId"]==ex["primarySkillId"])
            p["eligibleAfterSkillIds"]=[sid for sid in primary_skill.get("prerequisites",[]) if skill_intro.get(sid,999)<=ex["lessonNumber"]]
        if p.get("firstEligibleDelay")=="PT0H":
            p["eligibleAfterSkillIds"]=[sid for sid in p.get("eligibleAfterSkillIds",[]) if skill_intro.get(sid,999)<=ex["lessonNumber"]]
        p["approvedForRuntime"]=False;p["reviewStatus"]="needs_review"
        ex["approvedForRuntime"]=False;ex["humanEditorialReviewComplete"]=False;ex["nativeSpeakerReviewComplete"]=False;ex["reviewStatus"]="needs_review"
        check=ex.setdefault("editorialReviewChecklist",{})
        check["targetAlignment"]={"status":"pass","evidence":ex["targetAlignmentRationale"],"method":"revisión editorial individual"}
        check["naturalness"]={"status":"uncertain","evidence":"Revisión de IA completada; se conserva la revisión nativa pendiente.","method":"revisión lingüística de IA"}
    aby={a["exerciseId"]:a for a in assessments}
    for ex in exercises:
        if ex["id"] not in aby: continue
        a=aby[ex["id"]];a["prompt"]=ex["prompt"];a["referenceAnswer"]=canonical(ex);a["primarySkillId"]=ex["primarySkillId"]
        a["requiredElements"]=ex.get("structuredExpected",{}).get("requiredElements") or [canonical(ex)]
        a["coherenceEvidence"]=(f"La consigna solicita la información contenida en «{canonical(ex)}»; no se añaden participantes ni acciones ajenas.")
        a["approvedForRuntime"]=False
    # Register repaired gap under the existing atomic skill.
    repaired="pb1v16-l003-information-gap-reconstruction-05-5"
    for s in skills:
        if s["skillId"]=="identity_negation_ne" and repaired not in s["exerciseIds"]: s["exerciseIds"].append(repaired)

    # Audits: 40 readings, 50 exams, 650 spacing rows and skill references.
    prompt_rows=[]
    for eid in READING_ALIGNMENT:
        ex=eby[eid]
        prompt_rows.append({"exerciseId":eid,"russianText":ex["input"],"question":ex["prompt"],"referenceAnswer":canonical(ex),
          "contradictionDetected":False,"evidence":ex["targetAlignmentRationale"],"decision":"pass"})
    exam_rows=[]
    for ex in exercises:
        if ex["type"]!="exam":continue
        exam_rows.append({"exerciseId":ex["id"],"prompt":ex["prompt"],"referenceAnswer":canonical(ex),"primarySkillId":ex["primarySkillId"],
          "secondarySkillIds":"|".join(ex.get("secondarySkillIds",[])),"advancedUndocumentedConstruction":False,
          "semanticOrTemporalMismatch":False,"decision":"edit" if ex["id"] in EXAM_PATCHES else "keep","rationale":ex["targetAlignmentRationale"]})

    delay_days={"PT0H":0,"P1D":1,"P3D":3,"P4D":4,"P7D":7,"P14D":14,"P21D":21,"P28D":28}
    minimum={"next_day_retrieval":1,"short_delay_review":3,"weekly_review":7,"long_delay_review":14,"cumulative_exam":7,"delayed_exam":14}
    spacing_rows=[]
    for p in profiles:
        ex=eby[p["exerciseId"]];got=delay_days.get(p["firstEligibleDelay"],-1);need=minimum.get(p["sessionFunction"],0)
        future=max([skill_intro.get(s,ex["lessonNumber"]) for s in p.get("eligibleAfterSkillIds",[])]+[ex["lessonNumber"]])
        coherent=got>=need and not (p["sessionFunction"]=="initial_discovery" and future>ex["lessonNumber"])
        if p.get("reinsertionExerciseId") and p["reinsertionExerciseId"] not in eby: coherent=False
        spacing_rows.append({"exerciseId":p["exerciseId"],"primarySkillId":p["primarySkillId"],"sessionFunction":p["sessionFunction"],
          "firstEligibleDelay":p["firstEligibleDelay"],"eligibleAfterSkillIds":"|".join(p.get("eligibleAfterSkillIds",[])),
          "responseGenerationMode":p.get("responseGenerationMode"),"requiresFreeRecall":p.get("requiresFreeRecall"),
          "reinsertionExerciseId":p.get("reinsertionExerciseId"),"coherent":coherent,"rationale":"El intervalo satisface la función y no introduce una skill futura sin gating." if coherent else "Requiere corrección."})

    # Canonical outputs, preserving the frozen architecture.
    compat=json.loads(json.dumps(exercises,ensure_ascii=False))
    rename={
      "exercises_l001_l010_v1_9_3.json":exercises,"exercises_l001_l010_v1_9_3_compat.json":compat,
      "exercise_adaptive_profiles_l001_l010_v1_9_3.json":profiles,"assessment_plan_l001_l010_v1_9_3.json":assessments,
      "skills_l001_l010_v1_9_3.json":skills,"semantic_kernels_l001_l010_v1_9_3.json":kernels,
      "skill_trajectories_l001_l010_v1_9_3.json":trajectories,"vocabulary_l001_l010_v1_9_3.json":vocab,
      "lexical_coverage_l001_l010_v1_9_3.json":coverage,"lexical_encounters_l001_l010_v1_9_3.json":encounters,
      "feedback_templates_v1_9_3.json":feedback,"confusion_sets_v1_9_3.json":confusions,
      "recovery_protocols_v1_9_3.json":recovery,"normalization_policies_v1_9_3.json":normalization,
      "progress_model_schema_v1_9_3.json":progress}
    for name,data in rename.items():dump(CONTENT/name,data)

    integrity=[]
    for row in manifest["files"]:
        p=OUT/row["path"];h=hashlib.sha256(p.read_bytes()).hexdigest()
        integrity.append({"path":row["path"],"expectedSize":row["size"],"actualSize":p.stat().st_size,
          "expectedSha256":row["sha256"],"actualSha256":h,"exists":p.exists(),"verified":p.stat().st_size==row["size"] and h==row["sha256"]})
    write_csv(OUT/"PACKAGE_INTEGRITY_L011_L100_AUDIT_V1_9_3.csv",integrity)
    write_csv(OUT/"READING_TARGET_ALIGNMENT_AUDIT_V1_9_3.csv",reading_rows)
    write_csv(OUT/"READING_PROMPT_ANSWER_AUDIT_V1_9_3.csv",prompt_rows)
    write_csv(OUT/"INFORMATION_GAP_TARGET_AND_SCHEDULING_AUDIT_V1_9_3.csv",gap_rows)
    write_csv(OUT/"ASSESSMENT_ALIGNMENT_AUDIT_V1_9_3.csv",exam_rows)
    write_csv(OUT/"DISTRACTOR_DIAGNOSTIC_SPECIFICITY_AUDIT_V1_9_3.csv",diag_rows)
    write_csv(OUT/"SPACED_REPETITION_COHERENCE_AUDIT_V1_9_3.csv",spacing_rows)

    # Skill reference audit is reconstructed across every canonical structure.
    valid=set(skill_intro);ref_rows=[]
    def record(owner,path,sid): ref_rows.append({"owner":owner,"path":path,"skillId":sid,"exists":sid in valid,"decision":"pass" if sid in valid else "fail"})
    for ex in exercises:
        record(ex["id"],"primarySkillId",ex["primarySkillId"])
        for sid in ex.get("secondarySkillIds",[]):record(ex["id"],"secondarySkillIds",sid)
    for p in profiles:
        record(p["exerciseId"],"primarySkillId",p["primarySkillId"])
        for key in ("secondarySkillIds","eligibleAfterSkillIds","skillsCompeting"):
            for sid in p.get(key,[]):record(p["exerciseId"],key,sid)
    for k in kernels:
        for sid in k.get("primarySkills",[]):record(k["id"],"primarySkills",sid)
        for sid in k.get("competingSkills",[]):record(k["id"],"competingSkills",sid)
    for t in trajectories:record(t["trajectoryId"],"skillId",t["skillId"])
    for a in assessments:record(a["exerciseId"],"primarySkillId",a["primarySkillId"])
    for c in confusions:
        for sid in c.get("skills",[]):record(c["id"],"skills",sid)
    write_csv(OUT/"SKILL_REFERENCE_INTEGRITY_AUDIT_V1_9_3.csv",ref_rows)

    checklist=[]
    for ex in exercises:
        for name,item in ex.get("editorialReviewChecklist",{}).items():
            checklist.append({"exerciseId":ex["id"],"check":name,"status":item.get("status"),"evidence":item.get("evidence"),"method":item.get("method"),
              "specific":bool(item.get("evidence")) and item.get("evidence")!="La respuesta se obtiene del texto mediante un proceso integrative."})
    write_csv(OUT/"CHECKLIST_INTEGRITY_AUDIT_V1_9_3.csv",checklist)
    (OUT/"CHANGELOG_V1_9_2_TO_V1_9_3.md").write_text(
      "# Changelog v1.9.2 → v1.9.3\n\n- Incluidos y verificados los 117 archivos originales de L011–L100.\n"
      "- Eliminada la referencia inexistente `correction_ne_a`.\n- Revisados y alineados los targets de las 40 lecturas; corregida la contradicción temporal de L009.\n"
      "- Revisados los 20 information gaps y corregidas sus dependencias y programación.\n- Revisados los 50 exámenes y corregidos cuatro casos semánticos/curriculares.\n"
      "- Reescritos los 182 diagnósticos de distractor con categorías y causas concretas.\n- Sincronizados ejercicios, compat, perfiles y plan de evaluación.\n",
      encoding="utf-8")
    (OUT/"FINALIZATION_DECISION_V1_9_3.md").write_text("NOT_FINAL\n",encoding="utf-8")

if __name__=="__main__":main()
