#!/usr/bin/env python3
"""Read-only independent validator for Paruski v1.9.3.

This module does not import the builder and does not trust inherited pass fields.
It reconstructs cross-file relationships from the delivered JSON files.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
import tempfile
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

TOKEN_RE = re.compile(
    r"[A-Za-z\u0400-\u052f\u2de0-\u2dff\ua640-\ua69f\u0300-\u036f]+"
    r"(?:[-'’][A-Za-z\u0400-\u052f\u2de0-\u2dff\ua640-\ua69f\u0300-\u036f]+)*"
)
TOKEN_CASES = ["соба́ка", "тётя", "войти", "сейчас", "сайт", "английски", "живёт", "по-русски"]
MIXED_CASES = ["хлeб", "кoт", "cок", "мoре"]
RAW_KEYS = ("written_word", "written_name", "person_location", "photo_1", "photo_2", "key_owner", "Ivan_has_key", "woman_relation")
INTERPOLATED = (
    "responde a la consigna y realiza", "la respuesta debe conservar los datos de la consigna y producir",
    "debes reparar", "no basta con declarar una opción incorrecta", "revisa cualquier cambio de referente",
)


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def tokens(text: str | None):
    return TOKEN_RE.findall(unicodedata.normalize("NFC", text or ""))


def script(token: str):
    kinds = set()
    for ch in token:
        name = unicodedata.name(ch, "")
        if "CYRILLIC" in name:
            kinds.add("cyrillic")
        elif "LATIN" in name:
            kinds.add("latin")
    if kinds == {"cyrillic", "latin"}:
        return "mixed_cyrillic_latin"
    return next(iter(kinds), "other")


def norm(value):
    if value is None:
        return ""
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True)
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", value).lower()).strip().rstrip(".")


def flatten(value):
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        out = []
        for x in value: out += flatten(x)
        return out
    if isinstance(value, dict):
        out = []
        for x in value.values(): out += flatten(x)
        return out
    return []


def reference(ex):
    return ex.get("referenceAnswer") or ex.get("expectedAnswer") or ex.get("structuredExpected", {}).get("referenceAnswer")


def add(findings, code, severity, item, message):
    findings.append({"code": code, "severity": severity, "item": item, "message": message})


def paths(root: Path):
    c = root / "content"
    names = {
        "exercises": "exercises_l001_l010_v1_9_3.json",
        "compat": "exercises_l001_l010_v1_9_3_compat.json",
        "profiles": "exercise_adaptive_profiles_l001_l010_v1_9_3.json",
        "assessments": "assessment_plan_l001_l010_v1_9_3.json",
        "trajectories": "skill_trajectories_l001_l010_v1_9_3.json",
        "skills": "skills_l001_l010_v1_9_3.json",
        "kernels": "semantic_kernels_l001_l010_v1_9_3.json",
        "vocab": "vocabulary_l001_l010_v1_9_3.json",
        "coverage": "lexical_coverage_l001_l010_v1_9_3.json",
        "encounters": "lexical_encounters_l001_l010_v1_9_3.json",
        "confusions": "confusion_sets_v1_9_3.json",
        "recovery": "recovery_protocols_v1_9_3.json",
        "feedback": "feedback_templates_v1_9_3.json",
        "normalization": "normalization_policies_v1_9_3.json",
        "progress": "progress_model_schema_v1_9_3.json",
    }
    return {k: c / v for k, v in names.items()}


def validate(root: Path):
    findings = []
    ps = paths(root)
    for key, path in ps.items():
        if not path.exists():
            add(findings, "MISSING_CANONICAL_FILE", "blocker", key, str(path))
    if findings:
        return findings, {}
    data = {k: load(v) for k, v in ps.items()}
    exs = data["exercises"]
    ex_by = {x["id"]: x for x in exs}
    compat_by = {x["id"]: x for x in data["compat"]}
    prof_by = {x["exerciseId"]: x for x in data["profiles"]}
    cov_by = {x["exerciseId"]: x for x in data["coverage"]}
    ass_by = {x["exerciseId"]: x for x in data["assessments"]}

    # The untouched manifest is executable evidence: every declared path must
    # resolve inside this package and match both size and SHA-256.
    untouched_manifest = root / "UNCHANGED_L011_L100_MANIFEST.json"
    if not untouched_manifest.exists():
        add(findings, "L011_MANIFEST_MISSING", "blocker", untouched_manifest.name, "manifest not found")
    else:
        manifest = load(untouched_manifest)
        rows = manifest.get("files", [])
        if len(rows) != 117:
            add(findings, "L011_FILE_COUNT_MISMATCH", "blocker", untouched_manifest.name, f"declared={len(rows)} expected=117")
        for row in rows:
            path = root / row.get("path", "")
            if not path.is_file():
                add(findings, "L011_FILE_MISSING", "blocker", row.get("path", ""), "declared path is not resolvable")
                continue
            actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
            if path.stat().st_size != row.get("size") or actual_hash != row.get("sha256"):
                add(findings, "L011_HASH_MISMATCH", "blocker", row.get("path", ""), "size or SHA-256 differs")
        direct = [p for p in (root / "untouched_l011_l100").rglob("*") if p.is_file()] if (root / "untouched_l011_l100").exists() else []
        if len(direct) != 117:
            add(findings, "L011_FILE_COUNT_MISMATCH", "blocker", "untouched_l011_l100", f"actual={len(direct)} expected=117")
    source_zip = root / "source_v1_9_2" / "paruski_b1_materials_l001_l010_v1_9_2.zip"
    source_hash_file = root / "SOURCE_V1_9_2_SHA256.txt"
    if not source_zip.is_file() or not source_hash_file.is_file():
        add(findings, "SOURCE_V192_COPY_MISSING", "blocker", "source_v1_9_2", "source ZIP or hash record missing")
    else:
        expected = source_hash_file.read_text(encoding="utf-8").split()[0]
        actual = hashlib.sha256(source_zip.read_bytes()).hexdigest()
        if expected != actual:
            add(findings, "SOURCE_V192_HASH_MISMATCH", "blocker", source_zip.name, f"expected={expected} actual={actual}")

    if len(exs) != len(ex_by):
        add(findings, "DUPLICATE_ID", "blocker", "exercises", "Exercise IDs are not unique")
    if not 630 <= len(exs) <= 650:
        add(findings, "EXERCISE_COUNT", "high", "exercises", str(len(exs)))

    # Exact duplicate reconstruction, including scheduling.
    exact = defaultdict(list)
    family = defaultdict(list)
    for ex in exs:
        p = prof_by.get(ex["id"], {})
        key = (ex["type"], norm(ex.get("prompt")), norm(ex.get("input")), norm(reference(ex)), ex.get("cognitiveOperationId"))
        exact[key].append(ex["id"])
        fkey = (ex.get("exerciseFamilyId"), norm(ex.get("prompt")), norm(ex.get("input")), norm(reference(ex)))
        family[fkey].append(ex["id"])
        if ex.get("approvedForRuntime"):
            add(findings, "RUNTIME_ENABLED", "blocker", ex["id"], "approvedForRuntime=true")
        if p.get("approvedForRuntime"):
            add(findings, "RUNTIME_ENABLED", "blocker", ex["id"], "profile approvedForRuntime=true")
    for ids in exact.values():
        if len(ids) > 1:
            add(findings, "DUPLICATE_EXACT", "high", "|".join(ids), "type, prompt, input, answer and operation match")
            schedules = {(prof_by[i].get("firstEligibleDelay"), prof_by[i].get("sessionFunction")) for i in ids}
            if len(schedules) == 1:
                add(findings, "DUPLICATE_SAME_SCHEDULE", "high", "|".join(ids), "duplicate also shares interval and function")
    for ids in family.values():
        if len(ids) > 1:
            add(findings, "DUPLICATE_FAMILY_UNJUSTIFIED", "high", "|".join(ids), "same family, prompt, input and response")

    # Cross-file response consistency.
    for ex in exs:
        eid = ex["id"]
        ref = norm(reference(ex))
        candidates = []
        if ex.get("expectedAnswer") is not None: candidates.append(("expectedAnswer", ex["expectedAnswer"]))
        se = ex.get("structuredExpected", {})
        for key in ("referenceAnswer", "referenceResponse", "referenceExchange", "requiredCorrection"):
            if isinstance(se.get(key), str): candidates.append((f"structuredExpected.{key}", se[key]))
        for field, value in candidates:
            if norm(value) != ref:
                add(findings, "CROSS_FIELD_RESPONSE_MISMATCH", "blocker", eid, f"{field} differs from canonical reference")
        if eid not in compat_by or norm(reference(compat_by.get(eid, {}))) != ref:
            add(findings, "COMPAT_MISMATCH", "blocker", eid, "compat reference differs")
        if ex.get("isTransferOrExam"):
            if eid not in ass_by or norm(ass_by[eid].get("referenceAnswer")) != ref:
                add(findings, "ASSESSMENT_MISMATCH", "blocker", eid, "assessment reference differs")

    # Feedback, raw internal keys, animal translations and checklist integrity.
    generic_evidence = "La comprobación independiente no reconstruyó contradicciones en esta categoría."
    for ex in exs:
        eid = ex["id"]
        visible = " ".join(flatten([ex.get("prompt"), ex.get("input"), ex.get("validResponseExamples"), ex.get("partiallyCorrectResponse"), ex.get("incorrectPlausibleResponse"), ex.get("exerciseSpecificSuccessFeedback"), ex.get("exerciseSpecificErrorFeedback")]))
        for key in RAW_KEYS:
            if key in visible:
                add(findings, "RAW_KEY_VISIBLE", "high", eid, key)
        for field in ("exerciseSpecificSuccessFeedback", "exerciseSpecificErrorFeedback"):
            text = (ex.get(field) or "").lower()
            if any(piece in text for piece in INTERPOLATED):
                add(findings, "FEEDBACK_INTERPOLATED_TEMPLATE", "high", eid, field)
        for distractor, diagnosis in ex.get("distractorDiagnostics", {}).items():
            why = (diagnosis.get("whyItFails") or "").lower()
            if "no satisface la función o la forma exigida" in why:
                add(findings, "DISTRACTOR_DIAGNOSIS_GENERIC", "blocker", eid, distractor)
            if not diagnosis.get("category") or not diagnosis.get("meaning") or not diagnosis.get("whyItFails") or not diagnosis.get("repair"):
                add(findings, "DISTRACTOR_DIAGNOSIS_INCOMPLETE", "high", eid, distractor)
        if ex["type"] == "translation_ru_es" and any(a in (ex.get("input") or "").lower() for a in ("собака", "кошка")):
            if any("persona" in a.lower() for a in ex.get("acceptedAnswers", [])):
                add(findings, "ANIMAL_CALLED_PERSON", "blocker", eid, "invalid Spanish accepted answer")
        for check, item in ex.get("editorialReviewChecklist", {}).items():
            if item.get("status") == "pass" and not item.get("evidence"):
                add(findings, "CHECKLIST_PASS_NO_EVIDENCE", "high", eid, check)
            if item.get("evidence") == generic_evidence:
                add(findings, "CHECKLIST_GENERIC_MASS_EVIDENCE", "high", eid, check)

    # Prerequisite graph chronology and cycles.
    skill_by = {s["skillId"]: s for s in data["skills"]}
    intro = {sid: int(re.search(r"(\d+)$", s["introducedInLesson"]).group(1)) for sid, s in skill_by.items()}
    graph = {sid: s.get("prerequisites", []) for sid, s in skill_by.items()}

    def skill_ref(owner, field, sid):
        if sid not in skill_by:
            add(findings, "SKILL_REFERENCE_MISSING", "blocker", owner, f"{field}: {sid}")
        if sid == "correction_ne_a":
            add(findings, "FORBIDDEN_SKILL_REFERENCE", "blocker", owner, field)

    for ex in exs:
        skill_ref(ex["id"], "primarySkillId", ex.get("primarySkillId"))
        for field in ("secondarySkillIds", "competingSkillIds"):
            for sid in ex.get(field, []): skill_ref(ex["id"], field, sid)
    for p in data["profiles"]:
        skill_ref(p["exerciseId"], "primarySkillId", p.get("primarySkillId"))
        for field in ("secondarySkillIds", "eligibleAfterSkillIds", "skillsCompeting", "competingSkillIds"):
            for sid in p.get(field, []): skill_ref(p["exerciseId"], field, sid)
    for kernel in data["kernels"]:
        for field in ("primarySkills", "secondarySkills", "competingSkills"):
            for sid in kernel.get(field, []): skill_ref(kernel.get("id"), field, sid)
    for trajectory in data["trajectories"]: skill_ref(trajectory.get("trajectoryId"), "skillId", trajectory.get("skillId"))
    for assessment in data["assessments"]: skill_ref(assessment.get("exerciseId"), "primarySkillId", assessment.get("primarySkillId"))
    for confusion in data["confusions"]:
        for sid in confusion.get("skills", []): skill_ref(confusion.get("id"), "skills", sid)
    for sid, pres in graph.items():
        for pre in pres:
            if pre not in graph:
                add(findings, "PREREQUISITE_MISSING", "blocker", sid, pre)
            elif intro[pre] > intro[sid]:
                add(findings, "PREREQUISITE_FROM_FUTURE", "blocker", sid, f"{pre}: L{intro[pre]} > L{intro[sid]}")
    def visit(node, trail):
        if node in trail:
            add(findings, "PREREQUISITE_CYCLE", "blocker", node, " -> ".join(trail + [node])); return
        for nxt in graph.get(node, []): visit(nxt, trail + [node])
    for sid in graph: visit(sid, [])

    # Scheduling is checked against actual skill introduction rather than row
    # order or exercise type.
    delay_days = {"PT0H":0,"P1D":1,"P3D":3,"P4D":4,"P7D":7,"P14D":14,"P21D":21,"P28D":28}
    minima = {"next_day_retrieval":1,"short_delay_review":3,"weekly_review":7,"long_delay_review":14,"cumulative_exam":7,"delayed_exam":14}
    for p in data["profiles"]:
        ex = ex_by[p["exerciseId"]]
        lesson = ex.get("lessonNumber")
        future = [sid for sid in p.get("eligibleAfterSkillIds", []) if sid in intro and intro[sid] > lesson]
        if p.get("sessionFunction") == "initial_discovery" and future:
            add(findings, "FUTURE_SKILL_INITIAL_DISCOVERY", "blocker", ex["id"], "|".join(future))
        if future and p.get("firstEligibleDelay") == "PT0H":
            add(findings, "FUTURE_SKILL_PT0H", "blocker", ex["id"], "|".join(future))
        got = delay_days.get(p.get("firstEligibleDelay"), -1)
        need = minima.get(p.get("sessionFunction"), 0)
        if got < need:
            add(findings, "SPACING_INTERVAL_INCOMPATIBLE", "high", ex["id"], f"{p.get('sessionFunction')} at {p.get('firstEligibleDelay')}")

    # Unicode tokenization self-tests and delivered token audits.
    for sample in TOKEN_CASES:
        if tokens(sample) != [sample]:
            add(findings, "TOKENIZATION_FRAGMENTATION", "blocker", sample, repr(tokens(sample)))
    for sample in MIXED_CASES:
        if tokens(sample) != [sample] or script(tokens(sample)[0]) != "mixed_cyrillic_latin":
            add(findings, "MIXED_SCRIPT_FRAGMENTATION", "blocker", sample, repr(tokens(sample)))
    for eid, cov in cov_by.items():
        for component in ("visibleRussianInputCoverage", "requiredRussianOutputCoverage", "russianDistractorCoverage", "russianExplanationCoverage"):
            obj = cov.get(component, {})
            for tok in obj.get("tokenAudit", []):
                if tok.get("script") not in {"cyrillic", "mixed_cyrillic_latin"}:
                    add(findings, "COVERAGE_NON_RUSSIAN_TOKEN", "blocker", eid, tok.get("surface"))
                if len(tokens(tok.get("surface"))) != 1:
                    add(findings, "TOKENIZATION_FRAGMENTATION", "blocker", eid, tok.get("surface"))
        if not cov.get("instructionLanguageTokens", {}).get("excludedFromRussianCoverage"):
            add(findings, "SPANISH_IN_RUSSIAN_COVERAGE", "blocker", eid, "instructions not excluded")
        if ex_by[eid]["type"] == "translation_ru_es" and cov.get("requiredRussianOutputCoverage", {}).get("status") != "not_applicable":
            add(findings, "SPANISH_OUTPUT_TREATED_AS_RUSSIAN", "high", eid, "RU→ES output coverage must be N/A")

    # Reading thresholds, target alignment and prompt-answer coherence.
    past_re = re.compile(r"\b[А-Яа-яЁё]+(?:ла|ли|ло)\b")
    required_reading_targets = {
        "pb1v16-l001-reading-comprehension-03-3":"locative_zero_copula",
        "pb1v16-l001-reading-comprehension-09-1":"locative_zero_copula",
        "pb1v16-l002-reading-comprehension-03-3":"identity_answer_eto",
        "pb1v16-l003-reading-comprehension-06-2":"locative_zero_copula",
        "pb1v16-l004-reading-comprehension-09-1":"possession_u_genitive_est",
        "pb1v16-l005-reading-comprehension-03-3":"adjective_gender_number_agreement",
        "pb1v16-l006-reading-comprehension-03-3":"formal_informal_register",
        "pb1v16-l006-reading-comprehension-06-2":"eto_vs_personal_pronoun",
        "pb1v16-l006-reading-comprehension-09-1":"formal_informal_register",
        "pb1v16-l006-reading-comprehension-11-5":"formal_informal_register",
        "pb1v16-l007-reading-comprehension-03-3":"present_conjugation_zhit",
        "pb1v16-l008-reading-comprehension-03-3":"read_write_speak_contrast",
        "pb1v16-l009-reading-comprehension-09-1":"wh_semantic_scope",
        "pb1v16-l009-reading-comprehension-11-5":"answer_question_compatibility",
        "pb1v16-l010-reading-comprehension-06-2":"integrated_identity_reference",
        "pb1v16-l010-reading-comprehension-09-1":"integrated_present_actions",
    }
    for ex in exs:
        if ex["type"] == "reading_comprehension":
            c = cov_by[ex["id"]]["visibleRussianInputCoverage"]
            if c.get("coverage") is not None and c["coverage"] < .90 and not ex.get("coverageExceptionRationale"):
                add(findings, "READING_BELOW_THRESHOLD_NO_EXCEPTION", "high", ex["id"], str(c["coverage"]))
            if ex["lessonNumber"] <= 6 and past_re.search(ex.get("input") or "") and not ex.get("coverageExceptionRationale"):
                add(findings, "READING_UNINTRODUCED_GRAMMAR", "high", ex["id"], "past-tense morphology")
            if ex["id"] in required_reading_targets and ex.get("primarySkillId") != required_reading_targets[ex["id"]]:
                add(findings, "READING_TARGET_KNOWN_MISMATCH", "blocker", ex["id"], f"expected {required_reading_targets[ex['id']]} got {ex.get('primarySkillId')}")
            rationale = ex.get("targetAlignmentRationale") or ""
            if ex.get("primarySkillId") not in rationale or "evidencia" not in rationale.lower():
                add(findings, "READING_TARGET_EVIDENCE_MISSING", "high", ex["id"], "rationale does not connect primary skill to textual evidence")
            if ex["id"] == "pb1v16-l009-reading-comprehension-03-3":
                if "Днём она работает" not in (ex.get("input") or "") or "trabaja" not in (reference(ex) or "").lower():
                    add(findings, "READING_PROMPT_ANSWER_CONTRADICTION", "blocker", ex["id"], "daytime action must be работает / trabaja")
        if ex["type"] == "information_gap_reconstruction":
            se = ex.get("structuredExpected", {})
            exchange = se.get("referenceExchange") or reference(ex) or ""
            if "—" not in exchange or "?" not in exchange:
                add(findings, "INFORMATION_GAP_UNRESOLVED", "blocker", ex["id"], "missing question-answer exchange")
            if ex.get("primarySkillId") not in prof_by[ex["id"]].get("eligibleAfterSkillIds", []) and ex.get("primarySkillId") not in prof_by[ex["id"]].get("primarySkillId", ""):
                add(findings, "INFORMATION_GAP_TARGET_UNUSED", "high", ex["id"], ex.get("primarySkillId"))
            p = prof_by[ex["id"]]
            if p.get("sessionFunction") == "initial_discovery":
                add(findings, "INFORMATION_GAP_INITIAL_DISCOVERY", "high", ex["id"], "information exchange is scheduled as discovery")

        # A question of identity cannot silently be presented as an existential
        # Spanish prompt.  This also guards the known L003 exam failure.
        if "qué hay" in (ex.get("prompt") or "").lower() and "Что это?" in (reference(ex) or "") and not ex.get("identityExistenceDistinctionRationale"):
            add(findings, "EXAM_EXISTENCE_IDENTITY_MISMATCH", "blocker", ex["id"], "Что это? means what is this, not what is there")

    # Lexical encounter visibility and active vocabulary.
    product_by_item = defaultdict(set)
    for row in data["encounters"]:
        if row.get("mode") in {"uncued_recall", "delayed_uncued_recall"} and row.get("visibleBeforeResponse"):
            add(findings, "RECALL_FORM_VISIBLE", "high", row["exerciseId"], row.get("surface"))
        if row.get("requiredForSuccess") and row.get("mode") in {"uncued_recall", "delayed_uncued_recall", "assisted_recall", "copy_or_transform"}:
            product_by_item[row["lexicalItemId"]].add(row["exerciseId"])
    for item in data["vocab"]:
        if item.get("status") == "active" and not product_by_item[item["id"]]:
            add(findings, "VOCAB_ACTIVE_WITHOUT_PRODUCTIVE", "high", item["id"], item.get("lemma"))

    # Trajectory status is derived from the fixed general path, and report counts must match.
    general = ["discovery", "guided_recognition", "same_session_retrieval", "contextual_transfer", "delayed_retention"]
    traj_counts = Counter()
    for tr in data["trajectories"]:
        if tr.get("minimumCompletePath") != general:
            add(findings, "TRAJECTORY_MINIMUM_REDEFINED", "high", tr["trajectoryId"], str(tr.get("minimumCompletePath")))
        available = {s["stage"] for s in tr.get("stages", []) if s.get("exerciseIds")}
        missing = [s for s in general if s not in available]
        if missing != tr.get("missingStages"):
            add(findings, "TRAJECTORY_STAGE_MISMATCH", "high", tr["trajectoryId"], str(missing))
        traj_counts[tr.get("trajectoryStatus")] += 1
    metrics = {
        "exerciseCount": len(exs), "typeCount": len({e["type"] for e in exs}),
        "assessmentCount": len(data["assessments"]), "readingCount": sum(e["type"] == "reading_comprehension" for e in exs),
        "informationGapCount": sum(e["type"] == "information_gap_reconstruction" for e in exs),
        "trajectoryStatus": dict(traj_counts), "findingCounts": dict(Counter(f["severity"] for f in findings)),
        "canonicalFilesLoaded": sorted(ps), "untouchedFilesVerified": 117 if not any(f["code"].startswith("L011_") for f in findings) else 0,
    }
    return findings, metrics


def mutate_json(root: Path, key: str, fn):
    path = paths(root)[key]
    data = load(path)
    fn(data)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def mutation_tests(clean_root: Path):
    cases = []
    def run(name, expected, mutate):
        with tempfile.TemporaryDirectory(prefix="paruski_v193_mut_") as td:
            dst = Path(td) / "pkg"; shutil.copytree(clean_root, dst)
            mutate(dst)
            findings, _ = validate(dst)
            detected = sorted({f["code"] for f in findings})
            cases.append({"mutation": name, "expectedCode": expected, "detectedCodes": detected, "result": "pass" if expected in detected else "fail"})

    def remove_untouched(r):
        manifest=load(r/"UNCHANGED_L011_L100_MANIFEST.json"); (r/manifest["files"][0]["path"]).unlink()
    run("remove one of the 117 untouched files", "L011_FILE_MISSING", remove_untouched)

    def corrupt_hash(r):
        p=r/"UNCHANGED_L011_L100_MANIFEST.json"; d=load(p); d["files"][0]["sha256"]="0"*64; p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    run("change one untouched SHA-256", "L011_HASH_MISMATCH", corrupt_hash)

    run("assign nonexistent skill", "SKILL_REFERENCE_MISSING", lambda r: mutate_json(r,"exercises",lambda d:d[0].update({"primarySkillId":"skill_that_does_not_exist"})))

    def future_discovery(r):
        mutate_json(r,"profiles",lambda d:next(x for x in d if x["exerciseId"]=="pb1v15-l001-contextual-choice-01-1").update({"sessionFunction":"initial_discovery","firstEligibleDelay":"PT0H","eligibleAfterSkillIds":["wh_semantic_scope"]}))
    run("L009 skill as immediate L001 discovery", "FUTURE_SKILL_INITIAL_DISCOVERY", future_discovery)

    run("register reading assigned plural possessive", "READING_TARGET_KNOWN_MISMATCH", lambda r: mutate_json(r,"exercises",lambda d:next(x for x in d if x["id"]=="pb1v16-l006-reading-comprehension-03-3").update({"primarySkillId":"plural_possessive"})))

    def contradict_schedule(r):
        def edit(d):
            x=next(x for x in d if x["id"]=="pb1v16-l009-reading-comprehension-03-3");x["referenceAnswer"]="Por la mañana escribe y durante el día lee.";x["expectedAnswer"]=x["referenceAnswer"]
        mutate_json(r,"exercises",edit)
    run("Ana timetable answer contradicts daytime text", "READING_PROMPT_ANSWER_CONTRADICTION", contradict_schedule)

    run("Dónde/Cuándo reading marked yes-no", "READING_TARGET_KNOWN_MISMATCH", lambda r: mutate_json(r,"exercises",lambda d:next(x for x in d if x["id"]=="pb1v16-l009-reading-comprehension-09-1").update({"primarySkillId":"yes_no_question"})))

    def generic_diagnostic(r):
        def edit(d):
            x=next(x for x in d if x.get("distractorDiagnostics"));next(iter(x["distractorDiagnostics"].values()))["whyItFails"]="No satisface la función o la forma exigida por esta situación."
        mutate_json(r,"exercises",edit)
    run("insert generic distractor diagnosis", "DISTRACTOR_DIAGNOSIS_GENERIC", generic_diagnostic)

    run("retain correction_ne_a", "FORBIDDEN_SKILL_REFERENCE", lambda r: mutate_json(r,"exercises",lambda d:next(x for x in d if x["id"]=="pb1v16-l003-information-gap-reconstruction-05-5").update({"primarySkillId":"correction_ne_a"})))

    def que_hay(r):
        mutate_json(r,"exercises",lambda d:next(x for x in d if x["id"]=="pb1v16-l003-exam-13-2").update({"prompt":"Pregunta qué hay y responde.","identityExistenceDistinctionRationale":None}))
    run("Что это treated as qué hay", "EXAM_EXISTENCE_IDENTITY_MISMATCH", que_hay)
    return cases


def write_final_reports(root: Path, findings, metrics, mutations):
    blocking = [f for f in findings if f["severity"] in {"blocker", "high"}]
    mutations_ok = all(x["result"] == "pass" for x in mutations)
    decision = "FINAL_FOR_SCALING" if not blocking and mutations_ok else "NOT_FINAL"
    (root / "FINALIZATION_DECISION_V1_9_3.md").write_text(decision + "\n", encoding="utf-8")
    with (root / "FINAL_INDEPENDENT_FINDINGS_V1_9_3.csv").open("w", encoding="utf-8", newline="") as fh:
        fields = ["code", "severity", "item", "message"]
        w = csv.DictWriter(fh, fieldnames=fields); w.writeheader(); w.writerows(findings)
    traj = metrics.get("trajectoryStatus", {})
    report = [
        "# Auditoría independiente final v1.9.3",
        "",
        f"Decisión: `{decision}`.",
        "",
        "El auditor leyó directamente los quince archivos canónicos y no utilizó estados `pass` heredados como fuente de verdad.",
        "",
        f"- Ejercicios: {metrics.get('exerciseCount')}",
        f"- Tipos: {metrics.get('typeCount')}",
        f"- Evaluaciones o transferencias: {metrics.get('assessmentCount')}",
        f"- Lecturas: {metrics.get('readingCount')}",
        f"- Information gaps: {metrics.get('informationGapCount')}",
        f"- Archivos L011–L100 verificados: {metrics.get('untouchedFilesVerified')}/117",
        f"- Trayectorias por estado: {json.dumps(traj, ensure_ascii=False, sort_keys=True)}",
        f"- Hallazgos altos o bloqueadores: {len(blocking)}",
        f"- Mutaciones detectadas: {sum(x['result']=='pass' for x in mutations)}/{len(mutations)}",
        "",
        "Limitaciones declaradas: la revisión humana y nativa, el audio, la integración web y los datos personalizados permanecen pendientes. Ningún ejercicio está habilitado para runtime.",
    ]
    if blocking:
        report += ["", "## Bloqueadores", ""] + [f"- {f['code']} · {f['item']}: {f['message']}" for f in blocking]
    (root / "FINAL_INDEPENDENT_AUDIT_V1_9_3.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    (root / "VALIDATOR_MUTATION_TESTS_V1_9_3.json").write_text(json.dumps(mutations, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if decision == "FINAL_FOR_SCALING":
        (root / "NEXT_PROMPT_L011_L020_FINAL.md").write_text(
            "# Siguiente lote: L011–L020\n\n"
            "Usa `paruski_b1_materials_l001_l010_v1_9_3.zip` como baseline editorial y técnico congelado. "
            "Procesa L011–L020 sin modificar L001–L010 ni L021–L100. Aplica desde el inicio la separación entre contenido específico, "
            "feedback común, cobertura exclusivamente rusa, encuentros léxicos según visibilidad, prerrequisitos cronológicos, trayectorias honestas "
            "y validación independiente con pruebas de mutación. Completa en L011–L020 las etapas diferidas declaradas como ausentes, usando situaciones nuevas. "
            "Mantén `approvedForRuntime=false`, `reviewStatus=needs_review`, revisión humana y nativa pendientes, y no generes audio.\n",
            encoding="utf-8"
        )
    else:
        (root / "NEXT_PROMPT_L011_L020_FINAL.md").unlink(missing_ok=True)

    # Copy the reproducible scripts into the package before hashing.
    script_dir = Path(__file__).resolve().parent
    shutil.copy2(script_dir / "build_v19_3.py", root / "build_v19_3.py")
    shutil.copy2(Path(__file__).resolve(), root / "validate_v19_3_independent.py")

    # The manifest deliberately excludes itself; every other delivered file is hashed.
    manifest_path = root / "MANIFEST_SHA256_V1_9_3.csv"
    manifest_path.unlink(missing_ok=True)
    rows = []
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rows.append({"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    with manifest_path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["path", "bytes", "sha256"]); w.writeheader(); w.writerows(rows)
    return decision


def main():
    ap=argparse.ArgumentParser();ap.add_argument("root",type=Path);ap.add_argument("--mutation-tests",action="store_true");ap.add_argument("--write-reports",action="store_true");args=ap.parse_args()
    findings,metrics=validate(args.root)
    print(json.dumps({"findings":findings,"metrics":metrics},ensure_ascii=False,indent=2))
    muts = []
    if args.mutation_tests:
        muts = mutation_tests(args.root)
        print(json.dumps(muts,ensure_ascii=False,indent=2))
    if args.write_reports:
        if not muts:
            muts = mutation_tests(args.root)
        print(write_final_reports(args.root, findings, metrics, muts))
    raise SystemExit(1 if any(f["severity"] in {"blocker","high"} for f in findings) else 0)


if __name__ == "__main__": main()
