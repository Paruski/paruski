# Pasada editorial sobre v1.9.3 (L001–L010)

Aplicada por Claude, a petición del usuario, sin revisión de hablante nativo todavía.
Ver /home/claude/work/fixes_log en el chat para el detalle turno a turno; resumen aquí:

## Método
Auditoría automática (analizador morfológico de ruso) que cruza cada palabra rusa
exigida como respuesta correcta en cada ejercicio contra el vocabulario que esa lección,
y las anteriores, ya enseñan oficialmente (campo `introducedIn` de vocabulary_*.json).
Complementada con lectura manual de contexto para descartar falsos positivos
(palabras entregadas directamente en el enunciado, coincidencias parciales dentro de
otra palabra, metadatos obsoletos de versiones previas).

## Resultado
- 33 ejercicios corregidos en contenido (de 650 totales).
- 7 ejercicios reasignados a la lección donde su gramática se enseña realmente.
- 0 incidencias reales de vocabulario prematuro restantes, verificado con doble
  comprobación (límite de palabra + campos de respuesta genuinamente exigidos).
- Aún pendiente (no tocado en esta pasada): revisión humana/nativa, naturalidad fina
  de las traducciones, validez de cada distractor, exactitud de cada acento tónico,
  y las 90 lecciones restantes (L011–L100), que siguen en estado de borrador temprano.

## Alcance NO cubierto por esta pasada
Esta auditoría se centró específicamente en cronología de vocabulario (que ningún
ejercicio exija una palabra no enseñada todavía). No es una revisión gramatical
exhaustiva de los 650 ejercicios ni una validación de naturalidad por hablante nativo.
